### Hexlet tests and linter status:

[![Actions Status](https://github.com/krotkikhmaxim/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/krotkikhmaxim/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cfd5e966faee7192e360/maintainability)](https://codeclimate.com/github/krotkikhmaxim/python-project-49/maintainability)
