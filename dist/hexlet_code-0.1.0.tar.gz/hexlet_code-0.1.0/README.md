### Hexlet tests and linter status:

[![Actions Status](https://github.com/krotkikhmaxim/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/krotkikhmaxim/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cfd5e966faee7192e360/maintainability)](https://codeclimate.com/github/krotkikhmaxim/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/odikursv7gP2ZJkT6cYfOsSBS.svg)](https://asciinema.org/a/odikursv7gP2ZJkT6cYfOsSBS)
[![asciicast](https://asciinema.org/a/Vb4VjDQviMGzt2yl2XJmu1yLF.svg)](https://asciinema.org/a/Vb4VjDQviMGzt2yl2XJmu1yLF)
