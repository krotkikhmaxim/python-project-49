#!/usr/bin/env python3
from brain_games import function_set

def main():
    function_set.main()
    function_set.welcome()
    function_set.logic_brain_even()

if __name__ == '__main__':
    main()
